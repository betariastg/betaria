# flexbox

A Pen created on CodePen.io. Original URL: [https://codepen.io/Wahyu-Simangunsong/pen/gOdzEBz](https://codepen.io/Wahyu-Simangunsong/pen/gOdzEBz).

